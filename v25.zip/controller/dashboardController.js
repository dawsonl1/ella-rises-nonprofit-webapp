const getDashboard = (req, res) => {
  res.render('public/dashboard');
};

module.exports = {
  getDashboard,
};
